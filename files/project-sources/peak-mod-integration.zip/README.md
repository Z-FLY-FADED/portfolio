# PEAK 多人模组与中文界面整合配置

本包从项目归档提取实际使用的配置字段和值，供阅读和核对。配置节选保留原有键、值和节名。

- `doorstop_config.ini` 记录加载开关及 BepInEx 预加载程序集的相对路径。
- `BepInEx/config/PeakUnlimited.cfg` 记录 20 人上限与额外棉花糖设置。20 人为配置值。
- `BepInEx/config/AutoTranslatorConfig.ini` 记录中文设置、词条目录、UGUI 与 TextMeshPro 接口、静态翻译及回退字体配置。
- `plugin-dependencies.json` 记录三个实际插件清单中的名称、版本和依赖 ID。

使用这些配置需要自行取得 PEAK、Unity Doorstop、相应版本的 BepInEx、对应插件和 XUnity AutoTranslator。各插件的 BepInEx 依赖以所列清单为准。词条文本和 `lenmonziti` 字体需另行取得有权使用的副本。归档只包含以上配置节选和依赖元数据。
