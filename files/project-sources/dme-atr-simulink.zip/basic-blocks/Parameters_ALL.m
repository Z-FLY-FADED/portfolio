%% Electric Vehicle Init File
% 说明：
% - 本脚本初始化整车参数 + DME-ATR 参数 P + GA/SVR 控制器 cfg & Bus
% - 解决 Simulink Constant 输出 struct 时需要 BusObject 的问题：
%   GAConfigBus, SVRNumBus_H2, SVRNumBus_T
% - 依赖文件：
%   循环工况.mat, 电机参数.mat, 电池参数.mat, setpoints/setpoint23
%   (可选) svr_react3_num.mat  (由 react3_learn('train'/'all') 生成)

clear P;   % 注意：不要 clear/clear all，否则 Bus 会被清掉

%% --- 驾驶员子系统参数 ---
load 循环工况.mat;  % Sch_Cycle_1
n = 1;
Sch_Cycle = zeros(length(Sch_Cycle_1(:,2))*n, 2);
for j = 1:n
    for i = 1:length(Sch_Cycle_1(:,2))
        Sch_Cycle(i + (j-1)*length(Sch_Cycle_1(:,2)), 1) = i + (j-1)*length(Sch_Cycle_1(:,2));
        Sch_Cycle(i + (j-1)*length(Sch_Cycle_1(:,2)), 2) = Sch_Cycle_1(i, 2);
    end
end
clear i j n;

%% --- 控制器子系统参数 ---
Low_Speed = 10;
High_SOC = 0.9;
Mechanical_Brake_Ratio = 0.9;
Stop_SOC = 0.2;

%% --- 子系统参数 ---
Vehicle_Tire_Radius = 0.330;
Rolling_Resistance = 0.0115;
Rated_vertical_load = 10500;
Vehicle_Dr_HShaft_Inertia = 0.40;
Vehicle_Pa_HShaft_Inertia = 0.40;
Front_Tire_Inertia = 0.22;

Vehicle_Mass = 2100;
L = 2.85;
c_f = 1.38;
c_h = 0.60;
Frontal_area = 2.65;
Drag_coefficient = 0.33;

Vehicle_Rear_Diff_Ratio = 9.5;
Rear_Diff_Efficiency = 0.97;
Max_BrakeCylinder_pressure_Mpa = 25;
Vehicle_DShaft_Inertia = 0.18;

%% --- 电机子系统参数 ---
load 电机参数.mat;
Motor_Inertia = 0.1;

%% --- 电池子系统参数 ---
load 电池参数.mat;
Battery_Capacity = 160;
Battery_Initial_SOC = 0.8;
Accessories_Power_kW = 1.5;
Stop_SOC = 0.1;

%% --- 可视化子系统参数 ---
Logging_Sample_Time_s = 1;

%% --- params_ATR_P_tables.m ---
T = 573;

P.const.R = 8.314462618;
P.const.Tref = 298.15;

P.op.P_bar = 3.0;
P.op.Tc_K = 450;
P.op.T0 = 673;
P.meas.T_in = P.op.T0;

P.plant.UA = 150;
P.plant.Phi = 150;
P.plant.W_cat = 100;
P.plant.Nseg = 50;

P.limits.Tmin = 150;
P.limits.Tmax = 1300;

P.flags.simple_ads = false;

P.kin.OX.A = 1.0e5;  P.kin.OX.E = 60e3;  P.kin.OX.nO2 = 1.0;
P.kin.OX.alpha = 0.5;

P.kin.HYD.A = 2.0e5;  P.kin.HYD.E = 75e3;
P.kin.MSR.A = 8.0e4;  P.kin.MSR.E = 85e3;
P.kin.WGS.A = 2.0e4;  P.kin.WGS.E = 65e3;
P.kin.SR.A  = 1.0e5;  P.kin.SR.E  = 85e3;

P.kin.eps_drive = 1e-6;

P.ads.OX.K0    = [5e-3, 2e-3, 1e-3, 1e-6];
P.ads.OX.dHads = [-50e3,-35e3,-20e3,+8e3];
P.ads.OX.m     = 2;

P.ads.HYD.K0    = [1e-2, 5e-3, 5e-3];
P.ads.HYD.dHads = [-60e3,-45e3,-30e3];

P.ads.MSR.K0    = [6e-3, 4e-3, 2e-3, 1e-6];
P.ads.MSR.dHads = [-35e3,-30e3,-20e3,+8e3];

P.ads.WGS.K0    = [2e-3, 1e-6, 3e-3, 1e-3];
P.ads.WGS.dHads = [-30e3,+8e3,-35e3,-20e3];

P.ads.SR.K0     = [1e-2, 5e-3, 1e-3, 1e-6];
P.ads.SR.dHads  = [-60e3,-45e3,-20e3,+8e3];

Tb = (600:50:1100)';

P.tables.Cp.DME.T_breaks  = Tb;  P.tables.Cp.DME.vals  = linspace(120,140,numel(Tb))';
P.tables.Cp.H2O.T_breaks  = Tb;  P.tables.Cp.H2O.vals  = linspace(70, 95,numel(Tb))';
P.tables.Cp.H2.T_breaks   = Tb;  P.tables.Cp.H2.vals   = linspace(28, 31,numel(Tb))';
P.tables.Cp.CO2.T_breaks  = Tb;  P.tables.Cp.CO2.vals  = linspace(40, 55,numel(Tb))';
P.tables.Cp.CO.T_breaks   = Tb;  P.tables.Cp.CO.vals   = linspace(30, 45,numel(Tb))';
P.tables.Cp.O2.T_breaks   = Tb;  P.tables.Cp.O2.vals   = linspace(30, 44,numel(Tb))';
P.tables.Cp.MeOH.T_breaks = Tb;  P.tables.Cp.MeOH.vals = linspace(60, 75,numel(Tb))';

P.tables.dH.HYD.T_breaks = Tb;  P.tables.dH.HYD.vals = -3.0e4*ones(numel(Tb),1);
P.tables.dH.MSR.T_breaks = Tb;  P.tables.dH.MSR.vals = +5.0e4*ones(numel(Tb),1);
P.tables.dH.WGS.T_breaks = Tb;  P.tables.dH.WGS.vals = -4.1e4*ones(numel(Tb),1);
P.tables.dH.OX.T_breaks  = Tb;  P.tables.dH.OX.vals  = -1.2e6*ones(numel(Tb),1);
P.tables.dH.SR.T_breaks  = Tb;  P.tables.dH.SR.vals  = +6.0e4*ones(numel(Tb),1);

P.tables.Keq.HYD.T_breaks = Tb;  P.tables.Keq.HYD.lnK_vals = linspace(0, 2,numel(Tb))';
P.tables.Keq.MSR.T_breaks = Tb;  P.tables.Keq.MSR.lnK_vals = linspace(1, 5,numel(Tb))';
P.tables.Keq.WGS.T_breaks = Tb;  P.tables.Keq.WGS.lnK_vals = linspace(0.5, 3,numel(Tb))';
P.tables.Keq.SR.T_breaks  = Tb;  P.tables.Keq.SR.lnK_vals  = linspace(3, 9,numel(Tb))';

% ---- 生成 PBus & 推送 ----
tmp  = Simulink.Bus.createObject(P);
PBus = evalin('base', tmp.busName);
assignin('base','P',P);
assignin('base','PBus',PBus);

fprintf('\n— 参数总览 —\n');
fprintf('T=%.1fK | P=%.2f bar | T0=%.1f K | Tc=%.1f K | UA=%.1f W/K | W_cat=%.1f kg | Nseg=%d | Phi=%.1f | OX.alpha=%.3f\n', ...
   T, P.op.P_bar, P.op.T0, P.op.Tc_K, P.plant.UA, P.plant.W_cat, P.plant.Nseg, P.plant.Phi, P.kin.OX.alpha);

%% --- Fuel cell system parameters (示例占位) ---
fc_numberofcells = 50;
fc_activearea = 280;

%% --- Load setpoints ---
load('setpoints/setpoint23');

%% ============================================================
%% --- GA+SVR 控制器：cfg / GAConfigBus / SVRNumBus_H2/T ---
%% ============================================================

% 1) 创建 GAConfigBus（给 cfg Constant 用）
e(1)=Simulink.BusElement; e(1).Name='Tband'; e(1).Dimensions=[1 2]; e(1).DataType='double';
e(2)=Simulink.BusElement; e(2).Name='bdDME'; e(2).Dimensions=[1 2]; e(2).DataType='double';
e(3)=Simulink.BusElement; e(3).Name='bdRS';  e(3).Dimensions=[1 2]; e(3).DataType='double';
e(4)=Simulink.BusElement; e(4).Name='bdRO';  e(4).Dimensions=[1 2]; e(4).DataType='double';
GAConfigBus=Simulink.Bus; GAConfigBus.Elements=e;
assignin('base','GAConfigBus',GAConfigBus);

% 2) 加载 cfg / mdlH2 / mdlT（Simulink 用的数值化SVR结构体）
%    注意：svr_react3_num.mat 必须存在（由 react3_learn('train'/'all') 生成）
if exist('svr_react3_num.mat','file')==2
    S = load('svr_react3_num.mat','cfg','mdlH2','mdlT');
    cfg   = S.cfg;
    mdlH2 = S.mdlH2;
    mdlT  = S.mdlT;
else
    error('找不到 svr_react3_num.mat：请先运行 react3_learn(''train'') 生成 cfg/mdlH2/mdlT。');
end

assignin('base','cfg',cfg);

% 兼容你模型中 Constant1/2 的变量名
assignin('base','H2busVal',mdlH2);
assignin('base','TbusVal', mdlT);

% 3) 自动生成 SVRNumBus_H2 / SVRNumBus_T（Constant 输出 struct 必须显式Bus）
%    每次 init 都重建，避免你重新训练后支持向量数变化导致 Bus 不匹配
tmp = Simulink.Bus.createObject(mdlH2);
assignin('base','SVRNumBus_H2', evalin('base', tmp.busName));

tmp = Simulink.Bus.createObject(mdlT);
assignin('base','SVRNumBus_T',  evalin('base', tmp.busName));
