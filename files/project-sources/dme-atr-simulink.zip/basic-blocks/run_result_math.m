% 一键打开基础模块数学模型。运行本脚本后，可点击 Simulink 的“运行”。
modelFolder = fileparts(mfilename('fullpath'));
cd(modelFolder);
addpath(modelFolder);
init_result_math(modelFolder);
open_system(fullfile(modelFolder,'result.slx'));
set_param('result','SimulationCommand','update');
% 如需直接完成仿真，可在命令窗口执行：out = sim('result');
