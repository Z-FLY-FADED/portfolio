function init_result_math(project)
% 初始化原项目参数，隔离 ATR 总线名称与燃料电池数值参数 Cp。
if nargin==0, project=fileparts(mfilename('fullpath')); end
% Keep fuel-cell numeric Cp separate from the nested ATR bus named Cp.
old=pwd; cleanup=onCleanup(@()cd(old)); cd(project); addpath(project);
evalin('base','Parameters_ALL;');
root=evalin('base','PBus');
root=rename_bus(root);
assignin('base','PBus',root);
evalin('base','fcsdata;');
if exist(fullfile(project,'h2req.mat'),'file'), evalin('base','load(''h2req.mat'');'); end
end
function bus=rename_bus(bus)
elements=bus.Elements;
for k=1:numel(elements)
 typ=elements(k).DataType;
 if startsWith(typ,'Bus: '), source=strtrim(typ(6:end)); else, source=typ; end
 if evalin('base',sprintf('exist(''%s'',''var'')',source))
  child=evalin('base',source);
  if isa(child,'Simulink.Bus')
   dest=['ResultMathBus_' source];
   assignin('base',dest,rename_bus(child));
   elements(k).DataType=['Bus: ' dest];
  end
 end
end
bus.Elements=elements;
end

