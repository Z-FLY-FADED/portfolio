# DME-ATR 与 PEMFC 联合仿真

工程使用 MATLAB R2023a 和 Simulink。请先完整解压，再从对应子目录加载模型及同目录参数文件。

- original/model.slx 为整车联合模型，original/result.slx 为重整闭环模型。
- 在 original 目录运行 init_result_context(pwd)，随后打开 result.slx。
- 在 basic-blocks 目录运行 run_result_math.m，打开基础块版 result.slx 并更新模型。
- 两版闭环模型同名，请分别打开。setpoints 中保留各工况参数。

压缩包包含两个版本的可编辑模型、MATLAB 参数脚本、MAT 参数文件及闭环初始化脚本。
