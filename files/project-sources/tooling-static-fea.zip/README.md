# 底座、夹箍与气环工装静力分析 · Ansys 工程

完整解压 ZIP，并保留各 .wbpj 和同名 _files 文件夹的相对位置。源工程版本为 Ansys Workbench / Mechanical 2024 R1。建议使用同版本或支持读取该版本的更新版本。

| 算例 | Workbench 入口 | 几何 |
| --- | --- | --- |
| 底座 | `底座/dizuo.wbpj` | 同级 `123.STEP`，以及 DesignModeler `SYS.agdb` |
| 夹箍 | `夹箍仿真/jiagu.wbpj` | DesignModeler `SYS.agdb` 已包含。原项目引用的 `活塞环压缩器.STEP` 未随原归档保存，无法从该 STEP 刷新几何。 |
| 气环工装 | `气环工装/qihuan.wbpj` | 同级 `123.STEP` |

各算例保留 Mechanical 数据库、材料、求解输入 `ds.dat`、历史求解日志 `solve.out` 与警告记录 `file0.err`。若软件提示定位底座或气环几何，请选择相应目录的 `123.STEP`。完整求解结果需在兼容版本中重新计算。

原生工程文件保留原始内容。日志移除了本机路径及主机名。包内省略大型求解结果、会话日志、缓存、临时文件及机器专用脚本。已检查入口、关键文件及 ZIP 完整性，尚未在 Workbench 2024 R1 中打开或重新求解。
