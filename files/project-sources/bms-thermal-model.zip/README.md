BMS-S32K312 PCB 热仿真

ecad、geometry 和 pcb/tab 保存原板级建模资料。
steady/board 保存后续热模型使用的 ECAD 与铜层映射输入。
steady/20C 和 steady/40C 各包含 Icepak 保存的 .cas 网格、.dat 场数据、求解设置、峰温报告和残差记录。
公开版 .cas 文件首行移除了工作站标识。
steady/temperature-summary.csv 汇总两组峰温报告，温度单位为摄氏度。
