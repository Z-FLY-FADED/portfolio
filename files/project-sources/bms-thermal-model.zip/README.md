# BMS 板级热模型

## 工程入口

- 使用与保存版本相近的 Ansys Icepak Classic 24.1，在项目浏览器中选择 `pcb` 项目目录，保留 `pcb/tab/` 的层级与文件名。
- 需要重新导入时，在 Icepak 的 IDF 导入界面选择 `ecad/B.brd` 为板文件、`ecad/B.pro` 为器件库文件。`ecad/A.anf` 提供另一份板级电气和铜层信息，可用支持 ANF 的 Ansys 工具查看。`geometry/2024-01-23-BMS-S32K312-Ver1.0.step` 是板组件机械外形，可在支持 STEP 的 CAD 或 Ansys 建模器中单独导入。
- 需要可用的 Ansys Icepak 授权和兼容版本。AEDT 的经典 Icepak 项目导入入口使用 `.tzr` 存档格式，可先用 Icepak Classic 将项目目录归档。参见 [Ansys IDF 导入文档](https://ansyshelp.ansys.com/public/Views/Secured/corp/v242/en/ice_ug/ice_ug_sec_import_ecad_procedure.html) 和 [经典项目导入文档](https://ansyshelp.ansys.com/public/Views/Secured/Electronics/v242/en/Subsystems/Icepak/Content/Variables/OpeningIcepakClassicProjects.htm)。

## 文件范围

包含原 Icepak 模型及问题设置、IDF 板与器件库、ANF 文件和 STEP 外形。IDF 包含 334 个器件位置，可据此复核正反面分布及封装缺高的替代对象。包用于复核板级输入与模型设置。完整 Altium 电气设计、安装软件、历史工程、机器路径日志及温度场结果均在本包范围之外。

已核对归档完整性及原件字节一致性。当前包未在授权软件中重新打开或求解。
