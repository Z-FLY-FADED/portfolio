# 氨柴油燃烧 CONVERGE 样例

## 工程入口

- 在有授权的 CONVERGE Studio 中打开 `case/353.cvg`，查看已保存的样例工程。
- 使用 CONVERGE 3.0.17 兼容的求解环境时，将 `case/` 作为工作目录。保持 `inputs.in`、其余 `.in` 文件、几何 `surface.dat` 以及反应机理、热力学和物性数据的相对位置。原输入采用冷启动 `restart_flag: 0` 和 `map_flag: OFF`。
- 需要接收者自备兼容的 CONVERGE 授权与安装环境。现有静态核对未包含求解器重新运行。

## 文件范围

`case/` 包含原样例工程及输入。`validation/` 包含网页图表核对所需的原始结果，包括缸内与全域热力学序列、喷油记录、分区网格数量、三组壁面换热及边界映射。缸内区域使用 `thermo_region0.out`；喷油历程使用 `spray_rate_inj0.out`；三面换热使用 `bound2-wall.out`、`bound3-wall.out` 和 `bound4-wall.out`。

本包范围为已归档的单一 CONVERGE 样例。GT-Power 工程含本机用户目录及外部依赖，几何变体含原始联系字段，两类文件均未随样例提供。交接文档、机器路径日志、求解器及大体积运行产物也在本包范围之外。
