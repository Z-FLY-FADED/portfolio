# 连杆显式动力学仿真工程

## 工程入口

解压后，在 Ansys Workbench 中打开 `liangan/liangan.wbpj`，保持 `liangan_files/` 与它同级。工程由 Ansys Workbench 2022 R1 保存，框架版本为 22.1.217.0。编辑或重新求解需自备兼容的 Workbench、Mechanical 显式动力学及 Autodyn 授权。检查或编辑 CAD 时需相应的 SpaceClaim、DesignModeler 或兼容几何功能。

原项目保留 SYS、SYS-2、SYS-3、SYS-4 四套系统。每套系统包含可编辑 Mechanical 数据库、项目内 SpaceClaim 几何、材料定义、网格及初始求解输入。`admodel_0.ad` 是各系统的原始 Autodyn 初始模型文件。原 Workbench 有早期外部 `短连杆.STEP` 引用，该 STEP 未随原归档提供。需要检查形状时，使用包中的 `.scdoc` 或首套系统下的 `.agdb`、`.dsco` 几何文件。

## 能量时程与结果范围

`liangan_files/dp0/<系统>/MECH/file.gst` 保留四套系统的原始求解历史，可核对网站能量时程图。每份 GST 包含变量头和记录时间对应的数值，供表格与曲线核对。

`.adres` 全场结果、`.sum` 记录、`.ad` 后续周期快照、结果基文件、求解日志、临时缓存及远程运行脚本均未打包。需要全场云图或后续周期数据时，应在具备相应授权的环境中更新并重新求解。

归档条目、CRC 和原文件字节一致性已核验。尚未在授权软件中重新打开或求解。
